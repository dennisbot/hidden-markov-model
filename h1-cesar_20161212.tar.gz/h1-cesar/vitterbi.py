__author__="Marchelo Bragagnini <cesarbrma91@gmail>"
__date__="$Dic 09,2016"

import sys
from collections import defaultdict

CLASS_WORD_LOW_FREQUENT = "_RARE_"
WORD_INI = "*"
WORD_FIN = "STOP"

class Vitterbi(object):
    def __init__(self):
        self.s_all_tags = list()
        self.all_words = set()
        self.c_tags = defaultdict(int)
        self.emission_counts = defaultdict(int)
        
        self.q_ubt = defaultdict(float) # q parameter(unigram, bigram, trigram)        
        self.bp = defaultdict
        
    def gen_attributes(self, count_file):
        self.__init__()
        set_all_tags = set()        
        total_tags = 0
        c_ubt = defaultdict(int) # counts for unigram, bigram, trigram
        for line_file in count_file:
            line = line_file.strip()            
            fields = line.split(" ")
            # generate e(xi|yi) and c()           
            if fields[1] == "WORDTAG":                
                set_all_tags.add(fields[2])
                self.all_words.add(fields[3])
                self.emission_counts[(fields[2], fields[3])] += int(fields[0])            
                total_tags += int(fields[0])                
            # generate q(w) = c(w) / c()
            elif fields[1] == "1-GRAM":
                self.c_tags[fields[2]] = int(fields[0])
                #self.q_ubt[fields[2]] = (1.0 * self.c_tags[fields[2]]) / total_tags
            # generate q(w|v) = c(v,w) / c(v)
            elif fields[1] == "2-GRAM":
                c_ubt[(fields[2], fields[3])] = int(fields[0])
                #self.q_ubt[(fields[3],fields[2])] = (1.0 * c_ubt[(fields[2], fields[3])]) / self.c_tags[fields[2]]
            # generate q(w|u,v) = c(u,v,w) / c(u,v)               
            elif fields[1] == "3-GRAM":
                c_ubt[(fields[2],fields[3],fields[4])] = int(fields[0])
                self.q_ubt[(fields[4],fields[2],fields[3])] = (1.0 * c_ubt[(fields[2],fields[3],fields[4])]) / c_ubt[(fields[2], fields[3])]
        self.s_all_tags = list(set_all_tags)          

    def mapWo(self, word):
        if word not in self.all_words:
            return CLASS_WORD_LOW_FREQUENT
        return word

    def get_emmi_value(self, x, y):
        if self.c_tags[y] == 0:
            print "es cero beach y " + y
        return (1.0 * self.emission_counts[(y,x)]) / self.c_tags[y]
            
    def execute_with_bp(self, words):        
        n = words.__len__()
        card_s = self.s_all_tags.__len__()
        tags = [None] * (n+1)
        bp = defaultdict()      
        pi = defaultdict(float)
        pi[(0,"*","*")] = 1
        u = ""
        v = ""
        w = ""            
        for k in xrange(1,n+1):
            x_k = self.mapWo(words[k-1])
            for u_iter in xrange(0,card_s):
                u = self.s_all_tags[u_iter]
                if k == 1:
                    u = "*"
                for v_iter in xrange(0,card_s):
                    v = self.s_all_tags[v_iter]
                    probabilitie = -1.0
                    tag_w = ""
                    for w_iter in xrange(0,card_s):
                        w = self.s_all_tags[w_iter] 
                        if k <= 2:
                            w = "*"
                        temp = pi[k-1,w,u] * self.q_ubt[v,w,u] * self.get_emmi_value(x_k, v)
                        print "valor => %s %s %s %s %f %f\n"%(w,u,v,x_k,self.q_ubt[v,w,u],self.get_emmi_value(x_k,v))
                        if probabilitie < temp:
                            probabilitie = temp
                            tag_w = w
                    pi[(k,u,v)] = probabilitie                    
                    bp[(k,u,v)] = tag_w
                    print "valor %s %s %s %f\n"%(u,v,tag_w,pi[(k,u,v)])    
                
        probabilitie = -1.0                            
        for u_iter in xrange(0,card_s-1):
            u = self.s_all_tags[u_iter]            
            for v_iter in xrange(0, card_s-1):
                v = self.s_all_tags[v_iter]
                pro_temp = pi[(n,u,v)] * self.q_ubt[(WORD_FIN,u,v)]
                if probabilitie < pro_temp:
                     probabilitie = pro_temp
                     tags[n-1] = u
                     tags[n] = v
        for k in xrange(n-2,-1,-1):
            tags[k] = bp[(k+2, tags[k+1],tags[k+2])]        
        return tags                       
                       
    def calculate_tags(self, corpus_file, output):
        words = list()
        for line_file in corpus_file:         
            line = line_file.strip()
            if line:
                line = line.split(" ")
                words.append(line[0])                        
            else:            
                tags = self.execute_with_bp(words)            
                for i in xrange(0, words.__len__()):
                    output.write("%s %s\n"%(words[i],tags[i+1]))
                words = list()                
                output.write("\n")
        tags = self.execute_with_bp(words)        
        for i in xrange(0,words.__len__()):
            output.write("%s %s\n"%(words[i], tags[i+1]))
                                
def usage():
    sys.stderr.write(""" Usage python emission_tag.py [count_file] [test_file]  \n""")                           
                           
if __name__ == "__main__":
    if len(sys.argv) != 3:
        usage()
        sys.exit(2)
    
    try:
        nameCountFile = sys.argv[1]
        nameTestFile = sys.argv[2]
        inputCountFile = file(nameCountFile)
        inputTestFile = file(nameTestFile)
    except IOError:
        sys.stderr.write("ERROR: Cannot read inputfiles %s and %s \n" % sys.argv[1])
        sys.exit(1)
    vit = Vitterbi()    
    vit.gen_attributes(inputCountFile)    
    vit.calculate_tags(inputTestFile, sys.stdout)
                                        